import './App.css';
import UserTable from './Components/UserTable';

function App() {
  return (
    <div className="App">
    <UserTable />
    </div>
  );
}

export default App;
